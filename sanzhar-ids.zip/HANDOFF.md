﻿# Ветка sanzhar-ids (готово к мерджу)

## Что сделано
1. **Случайные ID + перемешивание строк (15 баллов):**
   - `schemas.py`: добавлены поля `id_scheme` ("sequential" | "randomized") и `id_salt` в `EpisodeConfig` + `history_json()`.
   - `generator.py`: добавлен `RandomizedIdScheme` (hex-ID DOC-xxxxxx, L-xxxxxx, INV/CN-xxxxxx, PAY-xxxxxx, CUST/SUP-xxxxxx + перемешивание таблиц + перемаппинг truth/provenance).
   - `env.py`: `AuditEnv.reset` принимает опциональный `id_scheme` и добавлен метод `env.abort(reason)`.
   - `evaluator.py`: `Evaluator.finalize` поддерживает `reason` при усечении/аборте.
2. **Процессная изоляция агента (часть 25 баллов за изоляцию):**
   - `runner.py` (НОВЫЙ): `SubprocessRunner`, `RunResult`, `run_episode_subprocess`, CLI. Запускает агента в отдельном процессе (пустая временная папка, очищенный env, python -I -B), общение строго по JSON-Lines, таймаут 60с, лимит строки 256 КБ, обработка падений/битого JSON/EOF/oversize.
   - `agent_protocol.py` (НОВЫЙ): сторона агента (`AgentSession`, `run_policy`) и встроенные тестовые агенты (`silent`, `random`, `replay`, `crash`, `slow`, `badjson`, `eof`, `oversize`, `hostile`).
3. **Тесты:**
   - `tests/test_ids_and_runner.py` (НОВЫЙ): 20 парных проверок инвариантности (Oracle получает одинаковую награду на sequential и randomized ID) + все тесты изоляции и сбоев `runner.py`.
   - `tests/test_core.py`: все 134 теста Этапа 1 сохранены и проходят.

## Проверка
`ash
pytest -v
`
Результат перед отправкой: **171 passed** (134 в test_core.py + 37 в test_ids_and_runner.py).
